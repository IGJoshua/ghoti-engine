ffi.cdef[[
typedef void *dBodyID;
typedef void *dSpaceID;
typedef void *dGeomID;
]]
