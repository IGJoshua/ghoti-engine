-- NOTE(Joshua): This is where you load the main scene

local C = engine.C

C.loadScene("ray_test")
