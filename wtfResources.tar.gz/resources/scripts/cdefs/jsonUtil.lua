ffi.cdef[[

int generateEntity(const char *filename);
int exportEntity(const char *filename);
int exportAsset(const char *filename);
int generateScene(const char *filename);
int exportScene(const char *filename);

]]
