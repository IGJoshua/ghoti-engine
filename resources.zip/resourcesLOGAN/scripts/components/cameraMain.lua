ffi.cdef[[
typedef struct camera_main_component_t
{
  UUID target;
  float time;
  float distance;
  float isTracking;
  float isOn;
} CameraMainComponent;
]]

local component = engine.components:register("camera_main", "CameraMainComponent")

component.numEntries = 1

io.write("Registered Main Camera Component\n")
