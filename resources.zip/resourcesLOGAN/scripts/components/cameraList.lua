ffi.cdef[[
typedef struct camera_list_component_t
{
  UUID mainCamera;
  UUID playerCamera;
  UUID extraCamera1;
  UUID extraCamera2;
  UUID extraCamera3;
  float totalTime;
  float timerTick;
  float currActiveCamera;
} CameraListComponent;
]]

local component = engine.components:register("camera_list", "CameraListComponent")

component.numEntries = 1

io.write("Registered Camera List Component\n")
