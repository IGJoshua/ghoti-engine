ffi.cdef[[
typedef struct enemy_component_t
{
  UUID target;
  float type;
  float health;
  float speed;
  float attackDamage;
  float time;
  float range;
  bool canSeePlayer;
  bool inCombat;
  kmVec3 direction;
} EnemyComponent;
]]

local component = engine.components:register("enemy", "EnemyComponent")

component.numEntries = 16

io.write("Registered Enemy Component")
