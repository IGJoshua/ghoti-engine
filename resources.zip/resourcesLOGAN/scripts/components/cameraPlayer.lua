ffi.cdef[[
typedef struct camera_player_component_t
{
  UUID target;
  UUID default;
  float time;
  float distance;
  float targetYaw;
  float targetPitch;
  float prevX;
  float prevY;
  float isOn;
} CameraPlayerComponent;
]]

local component = engine.components:register("camera_player", "CameraPlayerComponent")

component.numEntries = 1

io.write("Registered Player Camera Component\n")
