ffi.cdef[[
typedef struct shake_component_t
{
  float duration;
  float radius;
  bool shakeX;
  bool shakeY;
  bool shakeZ;
}ShakeComponent;
]]

local component = engine.components:register("shake", "ShakeComponent")

component.numEntries = 16

io.write("Registered Shake Component\n")
