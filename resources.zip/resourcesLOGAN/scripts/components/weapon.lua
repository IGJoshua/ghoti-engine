ffi.cdef[[
typedef struct weapon_component_t
{
  UUID player;
  float weapon_type;
  float attackModifier;
  float attackTick;
  float attackCounter;
  bool isAttacking;
  kmVec3 comboTimes;
  kmVec3 direction;
} WeaponComponent;
]]

io.write("Defined Weapon component for FFI\n")

local component = engine.components:register("weapon", "WeaponComponent")

component.numEntries = 12

io.write("Registered Weapon component\n")
