ffi.cdef[[
typedef struct player_component_t
{
  float health;
  float stamina;
  float attackDamage;
  float time;
  bool inCombat;
  bool sprintToggle;
  bool gamePaused;
  kmVec3 direction;
  kmVec3 desiredDirection;
} PlayerComponent;
]]

local component = engine.components:register("player", "PlayerComponent")

component.numEntries = 1

io.write("Registered Player component\n")
