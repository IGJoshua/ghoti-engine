ffi.cdef[[
typedef struct rigid_body_t
{
	bool dynamic_object;
	real32 gravityFactor;
	real32 mass;
	real32 elasticity;

	real32 drag;
	kmVec3 velocity;
	kmVec3 forces;

	kmVec3 centerOfMass;
} RigidBodyComponent;
]]

io.write("Defined RigidBody component for FFI\n")

local component = engine.components:register("rigid_body", "RigidBodyComponent")

local kazmath = engine.kazmath

function component:addForce(vec)
	local inParam = ffi.new("kmVec3[1]")
	if type(vec) == "cdata" then
		inParam[0] = vec
	else
		kazmath.kmVec3Fill(inParam, vec.x, vec.y, vec.z)
	end

	local outParam = ffi.new("kmVec3[1]", self.forces)
	kazmath.kmVec3Add(outParam, outParam, inParam)
	self.forces = outParam[0]
end

io.write("Registered RigidBody component\n")
