ffi.cdef[[
typedef struct jumpdash_component_t
{
  bool dashLeft;
  bool dashRight;
  float dashCounter;
  float dashCooldown;
  bool jump;
  bool doubleJump;
  float jumpCounter;
} JumpdashComponent;
]]

local component = engine.components:register("jumpdash", "JumpdashComponent")
component.numEntries = 16

io.write("Registered Jump/Dash component\n")
