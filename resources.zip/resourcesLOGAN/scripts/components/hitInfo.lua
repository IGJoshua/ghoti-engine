ffi.cdef[[
typedef struct hit_information_component_t
{
	UUID firstObject;
	UUID otherObject;
	UUID nextHit;
	bool resolved;
	kmVec3 penetrationAxis;
	real32 penetrationDist;
} HitInformationComponent;
]]

io.write("Defined Hit Information component for FFI\n")

local component = engine.components:register("hitInformation", "HitInformationComponent")

io.write("Registered Hit Information component\n")
