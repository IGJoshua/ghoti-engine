local system  = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad
local mouse = engine.mouse

system.components = {}
system.components[1] = "weapon"
system.components[2] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)
local zero = ffi.new("kmVec3[1]")
kazmath.kmVec3Fill(zero, 0, 0, 0)

local rtPressed = false
local ltPressed = false
local lightCounter, heavyCounter = 0.0, 0.0
local timer = 0.0
local pY = 0.0
local currCounter = 0.0
local outOfCombatTimer = 0.0

-- Expend Stamina
function staminaLoss(stm)
  stm = stm - 5.0
  if stm <= 0 then
    stm = 0
  end
  return stm
end

-- Restore Stamina
function staminaGain(stm)
  stm = stm + 0.1
  if stm >= 100 then
    stm = 100
  end
  return stm
end

-- Move weapon in a direction
function moveWeapon(xMod, yMod, zMod)
  local x = xMod
  local y = yMod
  local z = zMod
  local qForward = ffi.new("kmQuaternion[1]")
  local wForward = ffi.new("kmVec3", x, y, z)
  kazmath.kmQuaternionLookRotation(qForward, wForward, up)
  return qForward[0]
end

-- Determine which combo attack to use based on the light and heavy attack counters
function ComboAttack(lc, hc)
  if lc == 3 and hc == 0 then     -- Combo: LIGHT, LIGHT, LIGHT -- Fastest, Weakest
    io.write("LIGHT: 3 | HEAVY: 0\n")
    return 50.0, -20.0, 0.0, 5.0
  elseif lc == 2 and hc == 1 then -- Combo: LIGHT, LIGHT, HEAVY -- Fast, Weak
    io.write("LIGHT: 2 | HEAVY: 1\n")
    return 40.0, -25.0, 0.0, 7.0
  elseif lc == 1 and hc == 2 then -- Combo: LIGHT, HEAVY, HEAVY -- Slow, Strong
    io.write("LIGHT: 1 | HEAVY: 2\n")
    return -100.0, -50.0, 0.0, 10.0
  elseif lc == 0 and hc == 3 then -- Combo: HEAVY, HEAVY, HEAVY -- Slowest, Strongest
    io.write("LIGHT: 0 | HEAVY: 3\n")
    return -200.0, -100.0, 0.0, 15.0
  end
end

-- Shake the camera when player lands a combo
function shakeCamera(scene, duration, radius, shakeX, shakeY, shakeZ)
  local shake = scene:getComponent("shake", scene.ptr.mainCamera)
  shake.duration = duration
  shake.radius = radius
  shake.shakeX = shakeX
  shake.shakeY = shakeY
  shake.shakeZ = shakeZ
end

-- Set and check the attack tick and combo times for the weapon
function attackTimers(w, dt)
  -- Attack Timers
  if w.attackCounter > 0 then
    w.attackTick = w.attackTick + dt
    --io.write("Tick:   ".. w.attackTick.. "\n")
    if w.attackCounter == 1 then
      w.comboTimes.x = w.attackTick
      --io.write("Time 1: ".. w.comboTimes.x.."\n")
    elseif w.attackCounter == 2 then
      w.comboTimes.y = w.attackTick
      --io.write("Time 2: ".. w.comboTimes.y.."\n")
    elseif w.attackCounter == 3 then
      w.comboTimes.z = w.attackTick
      --io.write("Time 3: ".. w.comboTimes.z.."\n")
    end
  end
  return w.attackTick, w.comboTimes
end

function system.init(scene)
  input:register("leftclick", input.BUTTON(mouse.buttons[1]))
  input:register("rightclick", input.BUTTON(mouse.buttons[2]))
  input:register("lefttrigger", input.AXIS(nil, nil, gamepad.lefttrigger))
  input:register("righttrigger", input.AXIS(nil, nil, gamepad.righttrigger))
end

function system.run(scene, uuid, dt)
  -- Get Components
  local w = scene:getComponent("weapon", uuid) -- Weapon
  local wT = scene:getComponent("transform", uuid) -- Weapon Position
  --local p = scene:getComponent("player", w.player) -- Player
  local p = scene:getComponent("player", wT.parent)
  local pT = scene:getComponent("transform", wT.parent) -- Player Transform
  local pTAdv = scene:getComponent("jumpdash", wT.parent) -- Player Advanced movement

  wT.dirty = true
  pT.dirty = true
  if p.gamePaused == false then
    if p.health > 0 then
      -- Attach Weapon to left hand
      w.direction.x = p.desiredDirection.x
      w.direction.z = p.desiredDirection.z

      -- Light Attack Key Press
      if ((input.leftclick.keydown and input.leftclick.updated) or (input.righttrigger.value > 0 and rtPressed == false)) and p.stamina >= 5.0 then
        --p.inCombat = true
        p.stamina = staminaLoss(p.stamina)
        w.attackCounter = w.attackCounter + 1
        w.attackTick, w.comboTimes = attackTimers(w, dt)
        rtPressed = true
        timer = 3.0 - dt
        currCounter = w.attackCounter
        lightCounter = lightCounter + 1
        pY = pT.position.y
      elseif (not input.leftclick.keydown and input.righttrigger.value == 0) then
        rtPressed = false
        p.stamina = staminaGain(p.stamina)
      end

      -- Heavy Attack Key Press
      if ((input.rightclick.keydown and input.rightclick.updated) or (input.lefttrigger.value > 0 and ltPressed == false)) and p.stamina >= 10.0 then
        --p.inCombat = true
        p.stamina = staminaLoss(p.stamina)
        w.attackCounter = w.attackCounter + 1
        w.attackTick, w.comboTimes = attackTimers(w, dt)
        ltPressed = true
        timer = 4.0 - dt
        currCounter = w.attackCounter
        heavyCounter = heavyCounter + 1
        pY = pT.position.y
      elseif (not input.rightclick.keydown and input.lefttrigger.value == 0) then
        ltPressed = false
        p.stamina = staminaGain(p.stamina)
      end

      -- Reset attack counter if x amount of time passes before the next attack
      if w.attackCounter == currCounter then
        timer = timer - dt
        if timer < 0 then
          timer = 0.0
          w.attackCounter, lightCounter, heavyCounter = 0, 0, 0
          w.comboTimes = zero[0]
        end
      end

      -- Rest
      if w.attackTick == 0.0 then
        w.isAttacking = false
        wT.rotation = moveWeapon(w.direction.x, 0.0, w.direction.z)
        if p.inCombat == true then
          outOfCombatTimer = outOfCombatTimer + dt
          if outOfCombatTimer >= 4.0 then
            outOfCombatTimer = 0.0
            p.inCombat = false
          end
        end
      end

      -- Light Attack Action
      if rtPressed == true then
        if w.attackTick == 0.0 then -- Reset to original position
          wT.rotation = moveWeapon(w.direction.x, 0.0, w.direction.z)
        elseif w.attackTick < 0.175 then -- Attack if time is less than max time
          w.isAttacking = true
          if w.attackCounter > 2 and (w.comboTimes.z - w.comboTimes.x < 0.175) then -- Combo for 3 consecutive light attacks
            -- Call Combo function here
            local xD, yD, zD, dmg = ComboAttack(lightCounter, heavyCounter)
            w.attackCounter, lightCounter, heavyCounter = 0, 0, 0
            w.comboTimes = zero[0]
            p.attackDamage = w.attackModifier + dmg
            pT.position.y = pY
            wT.rotation = moveWeapon(w.direction.x + xD, w.direction.y + yD, w.direction.z + zD)
            shakeCamera(scene, 0.5, 1.0, false, true, true) -- Shake the camera a little when the player lands a light attack combo
          else -- Normal light attack
            p.attackDamage = w.attackModifier
            pT.position.y = pY
            wT.rotation = moveWeapon(w.direction.x, w.direction.y - 10.0, w.direction.z)
          end
          w.attackTick = 0.0 -- Reset attacking timer
        else -- Reset values
          w.attackTick = 0.0
          w.attackCounter, lightCounter, heavyCounter = 0, 0, 0
          w.isAttacking = false
          w.comboTimes = zero[0]
        end
      end

      -- Heavy Attack Action
      if ltPressed == true then
        if w.attackTick == 0.0 then -- Reset to original position
          wT.rotation = moveWeapon(w.direction.x, 0.0, w.direction.z)
        elseif w.attackTick < 0.31 then -- Attack if time is less than max time
          w.isAttacking = true
          if w.attackCounter > 2 and (w.comboTimes.z - w.comboTimes.x < 0.31) then -- Combo for 3 consecutive heavy attacks
            local xD, yD, zD, dmg = ComboAttack(lightCounter, heavyCounter)
            w.attackCounter, lightCounter, heavyCounter = 0, 0, 0
            w.comboTimes = zero[0]
            p.attackDamage = w.attackModifier + dmg
            pT.position.y = pY
            wT.rotation = moveWeapon(w.direction.x + xD, w.direction.y + yD, w.direction.z + zD)
            shakeCamera(scene, 0.7, 3.0, false, true, true) -- Shake the camera a lot when the player lands a heavy attack combo
          else -- Normal heavy attack
            p.attackDamage = w.attackModifier + 3.0
            pT.position.y = pY
            wT.rotation = moveWeapon(w.direction.x + 20.0, w.direction.y - 30.0, w.direction.z)
          end
          w.attackTick = 0.0
        else -- Reset values
          w.attackTick = 0.0
          w.attackCounter, lightCounter, heavyCounter = 0, 0, 0
          w.isAttacking = false
          w.comboTimes = zero[0]
        end
      end
    end
  end
end

io.write("Loaded the Player's Weapon system\n")
return system
