local system = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad

system.components = {}
system.components[1] = "enemy"
system.components[2] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)
local pOrigin = ffi.new("kmVec3")
local isPatrolling = false
local distance = 0.0
local isHit = false
local isPlayerHit = false
local hitTimer = 0.0

-- Set Position
function setPosition(x, y, z)
  local pos = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(pos, x, y, z)
  return pos[0]
end

-- Look At a Target
function LookAt(pos, tar, xMod, yMod, zMod)
  local v = ffi.new("kmVec3")
  v.x = (tar.x + xMod) - pos.x
  v.y = (tar.y + yMod) - pos.y
  v.z = (tar.z + zMod) - pos.z
  -- Convert Back to kmQuaternion
  local qForward = ffi.new("kmQuaternion[1]")
  kazmath.kmQuaternionLookRotation(qForward, v, up)
  return qForward[0]
end

-- Check if player is within range
function DetectPlayer(e, p, eT, pT, dt)
  local direction = ffi.new("kmVec3[1]")
  kazmath.kmVec3Subtract(direction, eT.position, pT.position)
  local distance = kazmath.kmVec3Length(direction)
  -- If too far away, do nothing
  if distance > e.range + 10.0 then
    return false, false, false
  -- If player is close enough to see, but not close enough to attack then look at them
  elseif distance < e.range + 10.0 and distance > e.range then
    return true, false, false
  -- If player is within range, then look at them and charge them
  elseif distance < e.range then
    return true, true, true
  end
end

-- Check if the player's weapon is close enough to damage the enemy.
function CheckWeaponPosition(eT, pW, pT)
  local temp = ffi.new("kmVec3[1]")
  kazmath.kmVec3Subtract(temp, eT.position, pT.position)
  local distance = kazmath.kmVec3Length(temp)
  --io.write("Distance: ".. distance.. "\n")
  if distance < 5.0 and pW.attackCounter > 0 then
    return true
  else
    return false
  end
end

-- Check a coordinate of the position in respect to the player's position
function CheckDistanceToPlayer(e, p, dt)
  -- e is enemy coordinate
  -- p is player coordinate
  -- can be used for x, y, z
  if e > p + 2.0 then
    e = e - (3.0 * dt)
    if e <= p + 2.0 then
      e = p + 2.0
    end
  elseif e < p - 2.0 then
    e = e + (3.0 * dt)
    if e >= p - 2.0 then
      e = p - 2.0
    end
  end
  return e
end

-- Attack
function CheckForAttack(e, eT, p, pT, dt)
  if hitTimer == 0 then
    local x = eT.position.x - pT.position.x
    local z = eT.position.z - pT.position.z
    if (x < 5.0 and x > -5.0) and (z < 5.0 and z > -5.0) then
      p.health = p.health - e.attackDamage
      if p.health < 0 then
        p.health = 0
      end
      return true, p.health
    else
      return false, p.health
    end
  else
    hitTimer = hitTimer - dt
    if hitTimer < 0 then
      hitTimer = 0
    end
    return false, p.health
  end
end

-- Patrol an area when player isn't around
function Patrol(e, eT, origin, radius, speed)
  local x = math.sin(e.time * speed) * radius + origin.x
  local y = eT.position.y
  local z = math.cos(e.time * speed) * radius + origin.z
  local position = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(position, x, y , z)
  return position[0]
end

-- Lose health
function takeDamage(hp, dmg, eT, pT, dt)
  hp = hp - dmg
  if hp < 0 then
    hp = 0
  end
  local x, y, z = 0, 0, 0
  -- Jump back from damage (X axis)
  if eT.position.x > pT.position.x then
    x = eT.position.x + (10.0 * dt * 3)
  else
    x = eT.position.x + (10.0 * dt * 3)
  end

  y = eT.position.y

  -- Jump back from damage (Z axis)
  if eT.position.z > pT.position.z then
    z = eT.position.z + (10.0 * dt * 3)
  else
    z = eT.position.z + (10.0 * dt * 3)
  end
  local position = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(position, x, y, z)
  return hp, position[0]
end

-- Gain Health
function healthGain(hp, rec)
  hp = hp + rec
  if hp > 100 then
    hp = 100.0
  end
  return hp
end

function system.init(scene)
  input:register("respawn", input.BUTTON(keyboard["4"], gamepad.dpad.left))
end

function system.run(scene, uuid, dt)
  local e = scene:getComponent("enemy", uuid)
  local p = scene:getComponent("player", e.target)
  local eT = scene:getComponent("transform", uuid)
  local pT = scene:getComponent("transform", e.target)

  local fcT = scene:getComponent("transform", pT.firstChild) -- Player's First Child
  local pW = scene:getComponent("weapon", fcT.nextSibling) -- Player's Weapon
  local pWT = scene:getComponent("transform", fcT.nextSibling) -- Player Weapon's transform
  eT.dirty = true
  pT.dirty = true

  if p.gamePaused == false then
    if e.health > 0 then
      e.time = e.time + dt
      -- Detect Player and look at player
      e.canSeePlayer, e.inCombat, p.inCombat = DetectPlayer(e, p, eT, pT, dt)
      if e.canSeePlayer == true then
        eT.rotation = LookAt(eT.position, pT.position, 0.0, 1.0, 0.0)
      end
      -- Movement
      if e.inCombat == true then -- Attack Player
        eT.position.x = CheckDistanceToPlayer(eT.position.x, pT.position.x, dt)
        eT.position.z = CheckDistanceToPlayer(eT.position.z, pT.position.z, dt)
        isPatrolling = false
      else -- Patrol
        if isPatrolling == false then
          x = math.random((eT.position.x - 5.0), (eT.position.x + 5.0))
          z = math.random((eT.position.z - 5.0), (eT.position.z + 5.0))
          kazmath.kmVec3Fill(pOrigin, x, eT.position.y, z)
          local temp = ffi.new("kmVec3[1]")
          kazmath.kmVec3Subtract(temp, eT.position, pOrigin)
          distance = kazmath.kmVec3Length(temp)
          isPatrolling = true
        end
        eT.position = Patrol(e, eT, pOrigin, distance, (e.speed / 2))
      end
      -- Combat
      if e.inCombat == true then
        -- Check if the player has hit the enemy
        isHit = CheckWeaponPosition(eT, pW, pT)
        if isHit == true then
          e.health, eT.position = takeDamage(e.health, p.attackDamage, eT, pT, dt)
          --io.write("Enemy Hit\n")
        end
        -- Check if the enemy has hit the player
        isPlayerHit, p.health = CheckForAttack(e, eT, p, pT, dt)
        if isPlayerHit == true then
          local shake = scene:getComponent("shake", scene.ptr.mainCamera)
          shake.duration = .2
          shake.radius = 5.0
          shake.shakeX = true
          shake.shakeY = true
          shake.shakeZ = false
          hitTimer = 1.0
        end
      else
        e.health = healthGain(e.health, 5.0)
      end
      -- Check if Player died
      if p.health < 0 then
        e.inCombat = false
      end
    else
      e.direction.x, e.direction.y, e.direction.z = 0.0, -100.0, 0.0
      if eT.position.y > -3.0 then
        eT.position.y = eT.position.y - 10.0 * dt
      end
      -- Respawn the enemy
      if input.respawn.keydown and input.respawn.updated then
        e.health = 100.0
        e.time = 0.0
        eT.position = setPosition(math.random(-30.0, 30.0), 0.5, math.random(-30.0, 30.0))
      end
    end
  end
end

io.write("Loaded the Enemy System\n")
return system
