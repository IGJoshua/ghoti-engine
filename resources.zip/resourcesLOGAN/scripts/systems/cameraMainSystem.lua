local system = {}
system.init = nil -- Runs in the beginning
system.shutdown = nil -- Runs in the end

local kazmath = engine.kazmath
local keyboard = engine.keyboard

system.components = {}
system.components[1] = "camera_main"
system.components[2] = "camera"
system.components[3] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)
local oldPos = ffi.new("kmVec3[1]")
local oldRot = ffi.new("kmQuaternion[1]")
local checkpoint = 0
local isPosEqual = false
local cutsceneIndex = 0
local timer = 0

local positions = {p1, p2, p3, p4, p5}
positions.p1 = ffi.new("kmVec3",  20.0, 20.0, -20.0) -- Cutscene 1.1
positions.p2 = ffi.new("kmVec3",  20.0, 20.0,  20.0) -- Cutscene 1.2
positions.p3 = ffi.new("kmVec3", -20.0, 20.0,  20.0) -- Cutscene 1.3
positions.p4 = ffi.new("kmVec3", -20.0, 20.0, -20.0) -- Cutscene 1.4
positions.p5 = ffi.new("kmVec3",  10.0,  4.0,  10.0) -- Cutscene 2.1
positions.p6 = ffi.new("kmVec3",   0.0,  0.0,   0.0) -- Cutscene 3.1

-- Return a new kmVec3 for a position
function setPosition(x, y, z)
  local pos = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(pos, x, y, z)
  return pos[0]
end

-- Look At a Target
function LookAt(pos, tar, xMod, yMod, zMod)
  local v = ffi.new("kmVec3")
  v.x = (tar.x + xMod) - pos.x
  v.y = (tar.y + yMod) - pos.y
  v.z = (tar.z + zMod) - pos.z
  -- Convert Back to kmQuaternion
  local qForward = ffi.new("kmQuaternion[1]")
  -- Set new kmQuaternion based off of v
  kazmath.kmQuaternionLookRotation(qForward, v, up)
  -- Set Camera Rotation to new kmQuaternion
  return qForward[0]
end
-- Turn To Desired Direction
function TurnTo(camTransform, direction, dt)
  local desiredQuat = ffi.new("kmQuaternion[1]")
  direction.z = -direction.z
  kazmath.kmQuaternionLookRotation(desiredQuat, direction, up)
  local qForward = ffi.new("kmQuaternion[1]")
  kazmath.kmQuaternionSlerp(qForward, camTransform.rotation, desiredQuat, dt) -- Swap desiredQuat and pTransform.rotation, this one has been swapped
  return qForward[0]
end
-- Make the camera move on "rails"
function MoveCameraOnRails(cam, camTransform, tar, dt, speed)
  -- X
  if camTransform.position.x ~= tar.x then
    if tar.x > 0 then
      camTransform.position.x = camTransform.position.x + (tar.x / tar.x) * (dt * speed)
      if camTransform.position.x > tar.x then
        camTransform.position.x = tar.x
      end
    elseif tar.x < 0 then
      camTransform.position.x = camTransform.position.x - (tar.x / tar.x) * (dt * speed)
      if camTransform.position.x < tar.x then
        camTransform.position.x = tar.x
      end
    end
  end

  -- Y
  camTransform.position.y = tar.y
  -- Z
  if camTransform.position.z ~= tar.z then
    if tar.x > 0 then
      camTransform.position.z = camTransform.position.z + (tar.z / tar.z) * (dt * speed)
      if camTransform.position.z > tar.z then
        camTransform.position.z = tar.z
      end
    elseif tar.z < 0 then
      camTransform.position.z = camTransform.position.z - (tar.z / tar.z) * (dt * speed)
      if camTransform.position.z < tar.z then
        camTransform.position.z = tar.z
      end
    end
  end

  if camTransform.position.x == tar.x and camTransform.position.z == tar.z then
    return camTransform, true
  else
    return camTransform, false
  end
end
-- Make the camera follow a circular path
function MoveCameraInCircle(cam, camTransform, origin, radius, speed)
  local x = math.sin(cam.time * speed) * radius + origin.x
  local y = origin.y + radius
  local z = math.cos(cam.time * speed) * radius + origin.z
  local position = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(position, x, y , z)
  return position[0]
end
-- WIP
function Point2Point(cam, tar, speed, dt)
  -- Find Vector between two points, distance, and direction
  local direction = ffi.new("kmVec3[1]")
  kazmath.kmVec3Subtract(direction, cam.position, tar.position)
  local distance = kazmath.kmVec3Length(direction)
  kazmath.kmVec3Normalize(direction, direction)
  -- Add, direction * speed * elapsed to position
  direction[0].x = direction[0].x * speed * dt
  direction[0].y = direction[0].y * speed * dt
  direction[0].z = direction[0].z * speed * dt
  -- Store Position in a temp variable
  local temp = ffi.new("kmVec3[1]")
  kazmath.kmVec3Fill(temp, cam.position.x, cam.position.y, cam.position.z)
  -- Add direction to position
  kazmath.kmVec3Add(temp, temp, direction)
  local length = kazmath.kmVec3Length(temp)
  if length < distance then
    return temp[0]
  elseif length > distance then
    kazmath.kmVec3Fill(temp, tar.position.x, tar.position.y, tar.position.z)
    return temp[0]
  end
  --[[
  -- Get Forward Vector
  local f = ffi.new("kmVec3[1]")
  kazmath.kmQuaternionGetForwardVec3RH(f, cam.rotation)
  -- Check angle between forward vector and v
  local cosine = kazmath.kmVec3Dot(v, f)
  local angle = kazmath.kmRadiansToDegrees(math.acos(cosine))
  io.write("Angle Between Vectors: ".. angle.. "\n")
  local isLeft, isRight = false, false
  if angle <= 90.0 and angle > 0.0 then -- To the left (positive angle)
  elseif angle >= -90.0 and angle < 0.0 then -- To the right (negative angle)
  else -- Straight ahead
  end
  ]]
end

function system.run(scene, uuid, dt)
  local mainCamera = scene:getComponent("camera_main", uuid)
  local actualCamera = scene:getComponent("camera", uuid)
  local cameraTransform = scene:getComponent("transform", uuid)
  local targetTransform = scene:getComponent("transform", mainCamera.target)
  
  mainCamera.time = mainCamera.time + dt
  -- Turn on tracking when camera is turned on
  if mainCamera.isOn == 1.0 then
    mainCamera.isTracking = 1.0
	if mainCamera.isTracking == 1.0 then

	  cameraTransform.dirty = true
	  targetTransform.dirty = true

      if cutsceneIndex == 0 then
        -- Look At
        cameraTransform.rotation = LookAt(cameraTransform.position, targetTransform.position, 0, 3, 0) -- Set Camera Rotation to new kmQuaternion
        -- movement
        if isPosEqual == false and checkpoint == 0 then
          cameraTransform, isPosEqual = MoveCameraOnRails(mainCamera, cameraTransform, positions.p1, dt, 30)
          if isPosEqual == true then
            isPosEqual, checkpoint = false, 1
            io.write("Checpoint 1 Reached\n")
          end
        elseif isPosEqual == false and checkpoint == 1 then
          cameraTransform, isPosEqual = MoveCameraOnRails(mainCamera, cameraTransform, positions.p2, dt, 30)
          if isPosEqual == true then
            isPosEqual, checkpoint = false, 2
            io.write("Checpoint 2 Reached\n")
          end
        elseif isPosEqual == false and checkpoint == 2 then
          cameraTransform, isPosEqual = MoveCameraOnRails(mainCamera, cameraTransform, positions.p3, dt, 30)
          if isPosEqual == true then
            isPosEqual, checkpoint = false, 3
            io.write("Checpoint 3 Reached\n")
          end
        elseif isPosEqual == false and checkpoint == 3 then
          cameraTransform, isPosEqual = MoveCameraOnRails(mainCamera, cameraTransform, positions.p4, dt, 30)
          if isPosEqual == true then
            isPosEqual, checkpoint, cutsceneIndex = false, 0, 1
            -- Turn To
            cameraTransform.position = setPosition(-10.0, 4.0, -10.0)
            local desiredDirection = ffi.new("kmVec3", -10.0, 4.0, 0)
            cameraTransform.rotation = TurnTo(cameraTransform, desiredDirection, dt)
            io.write("Checpoint 4 Reached\n")
          end
        end
      elseif cutsceneIndex == 1 then
        --actualCamera.fov = 60.0
        cameraTransform, isPosEqual = MoveCameraOnRails(mainCamera, cameraTransform, positions.p5, dt, 4)
        if cameraTransform.position.x > -0.5 and cameraTransform.position.x < 0.5 then
          local cameraShake = scene:getComponent("shake", scene.ptr.mainCamera)
          cameraShake.duration = 1.0
          cameraShake.radius = 6.0
          cameraShake.shakeX, cameraShake.shakeY, cameraShake.shakeZ = true, true, false
        end
        if isPosEqual == true then
          isPosEqual, cutsceneIndex = false, 2
          cameraTransform.position = setPosition(-20.0, 20.0, -20.0)
        end
      elseif cutsceneIndex == 2 then
        cameraTransform.rotation = LookAt(cameraTransform.position, positions.p6, 0, 1, 0)
        cameraTransform.position = MoveCameraInCircle(mainCamera, cameraTransform, positions.p6, 20.0, 3.0)
        timer = timer + dt
        if timer > 5.0 then
          timer, cutsceneIndex = 0.0, 0.0
          cameraTransform.position = setPosition(-20.0, 20.0, -20.0)
        end
      end
    end
  end
end

io.write("Loaded the Main Camera system\n")

return system
