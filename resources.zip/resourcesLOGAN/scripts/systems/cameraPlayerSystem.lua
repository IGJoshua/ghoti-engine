-- Make a local system first
local system = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad
local mouse = engine.mouse

system.components = {}
system.components[1] = "camera_player"
system.components[2] = "camera"
system.components[3] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)
local oldPos = ffi.new("kmVec3[1]")
local oldRot = ffi.new("kmQuaternion[1]")

local isIdle = false -- used to check if player has moved camera
local mouseUsed = false -- used to check if the player has used the mouse
local swapped = false -- used to check if isIdle has been toggled
local combatOver = true -- used to check when the player has exited combat

-- Camera States: alive, dead, idle

-- Look At a Target
function LookAt(pos, tar, xMod, yMod, zMod)
  local v = ffi.new("kmVec3")
  v.x = (tar.x + xMod) - pos.x
  v.y = (tar.y + yMod) - pos.y
  v.z = (tar.z + zMod) - pos.z
  -- Convert Back to kmQuaternion
  local qForward = ffi.new("kmQuaternion[1]")
  kazmath.kmQuaternionLookRotation(qForward, v, up)
  return qForward[0]
end

-- Turn To desired direction
function TurnTo(camTransform, direction, dt)
  local desiredQuat = ffi.new("kmQuaternion[1]")
  kazmath.kmQuaternionLookRotation(desiredQuat, direction, up)
  local qForward = ffi.new("kmQuaternion[1]")
  kazmath.kmQuaternionSlerp(qForward, camTransform.rotation, desiredQuat, dt) -- may need to swap camTransform.rotation and desiredQuat, they have been swapped
  return qForward[0]
end

-- Set the target yaw and pitch for the player camera
function YawPitch(targetYaw, targetPitch, _x, _y, dt)
  -- Set new yaw and pitch
  local yaw = targetYaw + (-_x * dt)
  local pitch = targetPitch + (_y * dt)
  -- Put limits on the yaw and pitch
  if pitch < -20.0 then
    pitch = -20.0
  elseif pitch > -18.566 then
    pitch = -18.566
  end
  while yaw > 3.1415 * 2 do
    yaw = yaw - 3.1415 * 2
  end
  -- Note
  -- playerCamera.targetYaw = yaw
  -- playerCamera.targetPitch = pitch
  return yaw, pitch
end

-- Helper function to modify the FOV
function ModifyFOV(fov, margin, goal, dt)
  -- Decrement
  if fov > goal then
    fov = fov - (margin * dt)
    if fov <= goal then
      fov = goal
    end
  -- Increment
  elseif fov < goal then
    fov = fov + (margin * dt)
    if fov >= goal then
      fov = goal
    end
  end
  return fov
end

function system.init(scene)
  input:register("horizontallook", input.AXIS(keyboard.LEFT, keyboard.RIGHT, gamepad.rightstick.xaxis))
  input:register("verticallook", input.AXIS(keyboard.UP, keyboard.DOWN, gamepad.rightstick.yaxis))
  input:register("scroll", input.AXIS(gamepad.dpad.down, gamepad.dpad.up, mouse.scroll.yaxis))
  input:register("reset", input.BUTTON(mouse.buttons[3], gamepad.buttons.rightstick))
  mouse.x = 0
  mouse.y = 0
end

function system.run(scene, uuid, dt)
  -- Get Total Time since component was activated
  local playerCamera = scene:getComponent("camera_player", uuid)
  local actualCamera = scene:getComponent("camera", uuid)
  local player = scene:getComponent("player", playerCamera.target)
  local cTransform = scene:getComponent("transform", uuid)
  local pTransform = scene:getComponent("transform", playerCamera.target)
  local dTransform = scene:getComponent("transform", playerCamera.default)

  -- Old Yaw/Pitch
  --[[
  -- Left and Right is YAW +/- dt
  if keyboard.LEFT.keydown then
    yaw = yaw - (2.0 * dt)
  elseif keyboard.RIGHT.keydown then
    yaw = yaw + (2.0 * dt)
  end
  -- Up and Down is Pitch +/- dt
  if keyboard.UP.keydown then
    pitch = pitch - (2.0 * dt)
  elseif keyboard.DOWN.keydown then
    pitch = pitch + (2.0 * dt)
  end
  --]]

  -- Set Camera state based off of player's status (WIP)
  -- Camera for when player is not dead
  if player.gamePaused == false then
    if playerCamera.isOn == 1.0 and player.health > 0 then
  	  cTransform.dirty = true
  	  pTransform.dirty = true
  	  dTransform.dirty = true
      local x, y  = 0, 0
      -- Check for controller input
      if input.horizontallook.value ~= 0 or input.verticallook.value ~= 0 then
        x = input.horizontallook.value * 3
        y = -input.verticallook.value * 3
        playerCamera.time = 0
        isIdle, mouseUsed = false, false
      elseif (input.horizontallook.value == 0 and input.verticallook.value == 0) and (input.horizontal.value ~= 0 or input.vertical.value) ~= 0 then
        if mouseUsed == false then
          playerCamera.time = playerCamera.time + dt
          if playerCamera.time > 10.0 then isIdle = true end
        else
          playerCamera.time = 0.0
          isIdle = false
        end
      end
      -- Check for mouse input
      if mouse.x ~= playerCamera.prevX or mouse.y ~= playerCamera.prevY then
        x = mouse.x - playerCamera.prevX
        y = mouse.y - playerCamera.prevY
        playerCamera.prevX = mouse.x
        playerCamera.prevY = mouse.y
        mouseUsed = true
        isIdle = false
      end
      -- If player is moving camera
      if isIdle == false then
        if swapped == true then
          -- Make camera return to original position after being idle smoothly
          kazmath.kmVec3Lerp(cTransform.position, cTransform.position, oldPos, dt)
          kazmath.kmQuaternionSlerp(cTransform.rotation, cTransform.rotation, oldRot, dt)
          swapped = false
        end
        -- Set Camera Yaw and Pitch
        playerCamera.targetYaw, playerCamera.targetPitch = YawPitch(playerCamera.targetYaw, playerCamera.targetPitch, x, y, dt)
        -- Set new quaternion
        local quat = ffi.new("kmQuaternion[1]")
        kazmath.kmQuaternionRotationPitchYawRoll(quat, playerCamera.targetPitch, playerCamera.targetYaw, 0)
        -- Set new direction from quaternion
        local dir = ffi.new("kmVec3[1]")
        kazmath.kmQuaternionGetForwardVec3RH(dir, quat)
        -- Scale the direction by the distance from target
        local offset = ffi.new("kmVec3[1]")
        kazmath.kmVec3Scale(offset, dir, -playerCamera.distance)
        -- Set new position based off of target position and direction
        local position = ffi.new("kmVec3[1]")
        local target = ffi.new("kmVec3[1]", pTransform.position)
        target[0].y = target[0].y + 5
        kazmath.kmVec3Add(position, offset, target)
        -- Set new Position
        cTransform.position = position[0]
        oldPos = cTransform.position -- Used for storing the position before going idle
        -- Set new look at
        kazmath.kmQuaternionLookRotation(cTransform.rotation, dir, up)
        oldRot = cTransform.rotation -- Used for storing the rotation before going idle
      elseif isIdle == true and player.inCombat == false then
        -- Get Direction of the player
        local dir = ffi.new("kmVec3[1]")
        kazmath.kmQuaternionGetForwardVec3RH(dir, pTransform.rotation)
        -- Make entity at a point behind the player based off of the direction the player is moving
        dTransform.position.x = pTransform.position.x + (dir[0].x)
        dTransform.position.y = pTransform.position.y + 6.0
        dTransform.position.z = pTransform.position.z + (dir[0].z + 6)
        -- Make camera look at player and lerp to entity
        kazmath.kmVec3Lerp(cTransform.position, cTransform.position, dTransform.position, dt * 2)
        cTransform.rotation = LookAt(cTransform.position, pTransform.position, 0, 3, 0)
        -- Bool
        swapped = true
      end

      -- Combat Camera
      if player.inCombat == true then
        -- Zoom camera out while in combat
        combatOver = false
        if actualCamera.fov < 110.0 then
          actualCamera.fov = ModifyFOV(actualCamera.fov, 100.0, 110.0, dt)
        end
      else
        -- Zoom camera in when combat is over
        if combatOver == false then
          actualCamera.fov = ModifyFOV(actualCamera.fov, 80.0, 80.0, dt)
          if actualCamera.fov == 80.0 then
            combatOver = true
          end
        end
      end

      -- Zooming (FOV)
      if input.scroll.value > 0 then
        actualCamera.fov = ModifyFOV(actualCamera.fov, 100.0, 40.0, dt)
      elseif input.scroll.value < 0 then
        actualCamera.fov = ModifyFOV(actualCamera.fov, 100.0, 120.0, dt)
      elseif (input.reset.keydown and input.reset.updated) then
        actualCamera.fov = 80
      end
    else
      cTransform.rotation = LookAt(cTransform.position, pTransform.position, 0, 3, 0)
    end
  end
end

io.write("Loaded the Player Camera system\n")

return system
