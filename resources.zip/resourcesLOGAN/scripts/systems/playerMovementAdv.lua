local system  = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad

system.components = {}
system.components[1] = "player"
system.components[2] = "jumpdash"
system.components[3] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)
local oldZ = 0
local jumpTimer = 0.0
local dashTimer = 0.0

function system.init(scene)
  input:register("jump", input.BUTTON(keyboard.SPACE, gamepad.buttons.a))
  input:register("dash", input.BUTTON(keyboard.LEFT_CONTROL, gamepad.buttons.b))
end

function system.run(scene, uuid, dt)
  local p = scene:getComponent("player", uuid)
  local pT = scene:getComponent("transform", uuid)
  local move = scene:getComponent("jumpdash", uuid)
  local fcT = scene:getComponent("transform", pT.firstChild) -- Player's First Child
  local pW = scene:getComponent("weapon", fcT.nextSibling) -- Player's Weapon
  local pWT = scene:getComponent("transform", fcT.nextSibling) -- Player Weapon's transform

  pT.dirty = true

  -- Use dashRight until 2 dashes confirmed
  if p.gamePaused == false then
    if input.dash.keydown and input.dash.updated then
      if move.dashCounter < 2 then
        move.dashRight = true
        move.dashCounter = move.dashCounter + 1
        move.dashCooldown = move.dashCooldown + 1.0
        oldZ = pT.position.z
        dashTimer = .25
      end
    end
    -- Dash Cooldown
    if move.dashCooldown > 0 then
      move.dashCooldown = move.dashCooldown - dt
      if move.dashCooldown <= 0 then
        move.dashCooldown = 0
        move.dashCounter = 0
        dashTimer = 0.0
      end
    end

    -- Jump Input
    if input.jump.keydown and input.jump.updated then
      if move.jump == false then
        move.jump = true
        jumpTimer = 0.3
      elseif move.jump == true and jumpTimer > 0 and move.doubleJump == false then
        move.doubleJump = true
        jumpTimer = 0.0
      end
    end
    -- Timer between jumps
    jumpTimer = jumpTimer - dt
    if jumpTimer < 0 then jumpTimer = 0 end


    -- Make Player Dash
    if move.dashRight == true then
      pT.position.x = pT.position.x + (p.desiredDirection.x) * (dt * 50)
      pT.position.z = pT.position.z + (p.desiredDirection.z) * (dt * 50)
      dashTimer = dashTimer - dt
      if dashTimer < 0 then
        dashTimer = 0
        move.dashRight = false
      end
    end
    -- Make Player Jump
    if move.jump == true then
      pT.position.y = pT.position.y + 70 * dt
      if pT.position.y > 10.0 then
        pT.position.y = 10.0
        if move.doubleJump == false then
          move.jump = false
        end
      end
    elseif move.jump == true and move.doubleJump == true and pW.isAttacking == false then
      -- Do a normal jump
      pT.position.y = pT.position.y + 70 * dt
      if pT.position.y > 30.0 then
        pT.position.y = 30.0
        move.jump = false
        move.doubleJump = false
      end
    elseif move.jump == false and move.doubleJump == false then
      if pW.isAttacking == false then
        pT.position.y = pT.position.y - 20 * dt
        if pT.position.y < 0 then
          pT.position.y = 0
        end
      end
    end
    --[[if move.doubleJump == true and pT.position.y > 0 then
      pT.position.y = pT.position.y + 70 * dt
      if pT.position.y > 20.0 then
        pT.position.y = 20.0
        move.doubleJump = false
      end
    end]]
  end
end

return system
