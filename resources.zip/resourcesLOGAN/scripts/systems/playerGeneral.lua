local system = {}
system.shutdown = nil

local C = engine.C
local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad

system.components = {}
system.components[1] = "player"
system.components[2] = "transform"

local playerDead = false
local prevHealth = 0.0
local respawnTime = 0.0
local saveLoaded = false

function healthLoss(hp, dmg)
  hp = hp - dmg
  if hp < 0 then
    hp = 0
  end
  return hp
end

function healthGain(hp, rec)
  hp = hp + rec
  if hp > 100 then
    hp = 100
  end
  return hp
end

function system.init(scene)
  input:register("close", input.BUTTON(keyboard.F4, gamepad.buttons.guide))
  input:register("pause", input.BUTTON(keyboard.ESCAPE, gamepad.buttons.start))
  --input:register("HPup", input.BUTTON(keyboard["2"], gamepad.buttons.rightbumper))
  --input:register("HPdn", input.BUTTON(keyboard["3"], gamepad.buttons.leftbumper))
  input:register("interact", input.BUTTON(keyboard.E, gamepad.buttons.y))
end
function system.run(scene, uuid, dt)
  local p = scene:getComponent("player", uuid)
  local pTransform = scene:getComponent("transform", uuid)

  pTransform.dirty = true

  -- Quit the game
  if input.close.keydown then
    engine.C.closeWindow()
  end
  -- Pause the Game
  if input.pause.keydown and input.pause.updated then
    if p.gamePaused == false then
      p.gamePaused = true
      io.write("GAME PAUSED\n")
    else
      p.gamePaused = false
      io.write("GAME UNPAUSED\n")
    end
  end

  -- Pause the game
  if p.gamePaused == true then
    -- Save
    if (gamepad.buttons.a.keydown and gamepad.buttons.a.updated) or (keyboard["2"].keydown and keyboard["2"].updated) then
      C.exportSave(nil, 0, 1)
      io.write("Game Saved\n")
    end
    -- Set bool to true to load the save when unpaused
    if (gamepad.buttons.y.keydown and gamepad.buttons.y.updated) or (keyboard["3"].keydown and keyboard["3"].updated) then
      saveLoaded = true
    end
    -- Backout of paused game
    if (gamepad.buttons.b.keydown and gamepad.buttons.b.updated) then
      p.gamePaused = false
      io.write("GAME UNPAUSED\n")
    end
  else
    -- Load the game after unpausing
    if saveLoaded == true then
      C.loadSave(1, nil)
      saveLoaded = false
      io.write("Game Loaded\n")
    end
    -- Health
    if p.health > 0 then
      -- Enter Combat through damage
      if prevHealth > p.health then
        p.inCombat = true
      end
      prevHealth = p.health
      -- Regenerate health when out of combat
      if p.inCombat == false then
        p.health = healthGain(p.health, 2.0 * dt)
        --io.write("Player Health: ".. p.health.. "\n")
      end
    else
      -- Set the respawn time when the player dies
      if playerDead == false then
        playerDead = true
        respawnTime = 3.0
      end
      -- Decrement respawn timer
      respawnTime = respawnTime - dt
      -- Respawn the player when timer hits 0
      if respawnTime < 0 then
        respawnTime = 0.0
        p.health = 100
        p.stamina = 100
        -- p.dashCount = 0.0
        pTransform.position.x = 0
        pTransform.position.y = 0
        pTransform.position.z = -10
      end
    end
  end
end

io.write("Loaded the General Player System\n")
return system
