-- Make a local system first
local system = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad
local mouse = engine.mouse

system.components = {}
system.components[1] = "shake"
system.components[2] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)

function system.init(scene)
  --input:register("shake", input.BUTTON(keyboard.TAB, gamepad.dpad.right))
end

function system.run(scene, uuid, dt)
  local shake = scene:getComponent("shake", uuid)
  local transform = scene:getComponent("transform", uuid)

  transform.dirty = true

  -- Shake Testing
  --[[
  if input.shake.keydown and input.shake.updated then
    shake.duration = math.random(0.1, 2.0)
    shake.radius = 10.0
    shake.shakeX, shake.shakeY, shake.shakeZ = true, true, true
  end
  ]]
  
  if shake.duration > 0 then
    -- Generate random angles
    local theta = math.random(0, 2 * math.pi)
    local phi = math.random(-(math.pi/2), math.pi/2)
    local radius = math.random(0, shake.radius)
    -- Generate random coordinate
    local x, y, z = transform.position.x, transform.position.y, transform.position.z
    if shake.shakeX == true then
      x = radius * math.cos(theta) * math.cos(phi)
    end
    if shake.shakeY == true then
      y = radius * math.sin(phi)
    end
    if shake.shakeZ == true then
      z = radius * math.sin(theta) * math.cos(phi)
    end
    -- Jitter Camera
    local vShake = ffi.new("kmVec3", x, y, z)
    kazmath.kmVec3Lerp(transform.position, transform.position, vShake, dt)
    -- decrement time
    shake.duration = shake.duration - dt
    if shake.duration < 0 then
      shake.duration = 0
      shake.radius = 0
      shake.shakeX, shake.shakeY, shake.shakeZ = true, true, true
    end
  end
end
io.write("Loaded Shake System\n")
return system

-- Camera Jitter
--[[
if input.shake.keydown and input.shake.updated then
  shakeTime = math.random(0.1, 2.0)
end
if shakeTime > 0 then
  -- Generate random angles
  local theta = math.random(0, 2 * math.pi)
  local phi = math.random(-(math.pi/2), math.pi/2)
  local radius = math.random(0, 10)
  -- Generate random coordinate
  local x = radius * math.cos(theta) * math.cos(phi)
  local y = radius * math.sin(phi)
  local z = radius * math.sin(theta) * math.cos(phi)
  -- Jitter Camera
  local vShake = ffi.new("kmVec3", x, y, z)
  kazmath.kmVec3Lerp(cTransform.position, cTransform.position, vShake, dt)
  -- decrement time
  shakeTime = shakeTime - dt
  if shakeTime < 0 then
    shakeTime = 0
  end
end
]]
