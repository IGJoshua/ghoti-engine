local system = {}

local kazmath = engine.kazmath

system.components = {}
system.components[1] = "rigid_body"

local direction = {}
direction.x = 0
direction.y = 9.5
direction.z = 0

function system.run(scene, entity, dt)
    local rigidBody = scene:getComponent("rigid_body", entity)

    local force = {}
    force.x = direction.x * dt * rigidBody.mass
    force.y = direction.y * dt * rigidBody.mass
    force.z = direction.z * dt * rigidBody.mass

    rigidBody:addForce(force)
end

return system
