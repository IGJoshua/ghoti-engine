local system  = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad

system.components = {}
system.components[1] = "player"
system.components[2] = "transform"

local up = ffi.new("kmVec3", 0, 1, 0)

function CalculateShortestRot(currentR, desiredR)
  -- Get angle and axis of current rotation
  local cAngle = ffi.new("kmScalar[1]")
  local cAxis = ffi.new("kmVec3[1]")
  kazmath.kmQuaternionToAxisAngle(currentR, cAxis, cAngle)
  cAngle[0] = kazmath.kmRadiansToDegrees(cAngle[0])
  --io.write("Angle 1: " .. cAngle[0] .. "\n") -- Print out the angle in degrees

  -- Get angle and axis of desired rotation
  local dAngle = ffi.new("kmScalar[1]")
  local dAxis = ffi.new("kmVec3[1]")
  kazmath.kmQuaternionToAxisAngle(desiredR, dAxis, dAngle)
  dAngle[0] = kazmath.kmRadiansToDegrees(dAngle[0])
  --io.write("Angle 2: " .. dAngle[0] .. "\n\n") -- Print out the angle in degrees

  return cAngle[0], dAngle[0]
end
function system.init(scene)
  input:register("horizontal", input.AXIS(keyboard.A, keyboard.D, gamepad.leftstick.xaxis))
  input:register("vertical", input.AXIS(keyboard.W, keyboard.S, gamepad.leftstick.yaxis))
  input:register("sprint", input.BUTTON(keyboard.LEFT_SHIFT, gamepad.buttons.leftstick))
end

function system.run(scene, uuid, dt)
  local p = scene:getComponent("player", uuid)
  local pTransform = scene:getComponent("transform", uuid)

  pTransform.dirty = true
  if p.gamePaused == false then
    if p.health > 0 then
      if input.horizontal.value ~= 0 or input.vertical.value ~= 0 then
        -- Get Camera x axis from rotation
        local camRotation = scene:getComponent("transform", scene.ptr.mainCamera).rotation
        local xaxis = ffi.new("kmVec3[1]")
        kazmath.kmQuaternionGetRightVec3(xaxis, camRotation)
        -- Cross x axis with up vector to get z axis
        local zaxis = ffi.new("kmVec3[1]")
        kazmath.kmVec3Cross(zaxis, xaxis, up)
        -- Cross Z axis with Up to new X axis
        kazmath.kmVec3Cross(xaxis, zaxis, up)
        -- Multiply z Axis by vertical input axis (input.vertical.value)
        kazmath.kmVec3Scale(zaxis, zaxis, input.vertical.value)
        -- Multiply x axis by horizontal input axis (input.horizontal.value)
        kazmath.kmVec3Scale(xaxis, xaxis, input.horizontal.value)
        -- Add results together, then normalize it to get desiredDirection
        local result = ffi.new("kmVec3[1]")
        kazmath.kmVec3Add(result, xaxis, zaxis)
        kazmath.kmVec3Normalize(p.desiredDirection, result)
        -- use turnTo to make player turn that direction
        p.desiredDirection.z = -p.desiredDirection.z
        p.desiredDirection.x = -p.desiredDirection.x
        local desiredQuat = ffi.new("kmQuaternion[1]")
        kazmath.kmQuaternionLookRotation(desiredQuat, p.desiredDirection, up)
        local qForward = ffi.new("kmQuaternion[1]")
        -- Calculate shortest distance here
        local c, a = CalculateShortestRot(pTransform.rotation, desiredQuat)

        kazmath.kmQuaternionSlerp(qForward, desiredQuat, pTransform.rotation, dt * 5) -- Swap desiredQuat and pTransform.rotation, they have been swapped
        pTransform.rotation = qForward[0]

        -- Toggle Sprint
        if input.sprint.keydown and input.sprint.updated then
          if p.sprintToggle == false then
            p.sprintToggle = true
          else
            p.sprintToggle = false
          end
        end

        p.desiredDirection.z = -p.desiredDirection.z

        -- Movement
        local cameraShake = scene:getComponent("shake", scene.ptr.mainCamera)
        if p.sprintToggle == true then
          cameraShake.duration = 0.1
          cameraShake.radius = 2.0
          cameraShake.shakeX, cameraShake.shakeY, cameraShake.shakeZ = false, true, true
          pTransform.position.x = pTransform.position.x + (p.desiredDirection.x * (dt * 12))
          pTransform.position.z = pTransform.position.z + (p.desiredDirection.z * (dt * 12))
        else
          pTransform.position.x = pTransform.position.x + (p.desiredDirection.x * (dt * 6))
          pTransform.position.z = pTransform.position.z + (p.desiredDirection.z * (dt * 6))
        end
      else
        p.sprintToggle = false
      end
      -- Old stuff
      --[[
      local isMovingZ = false
      local isMovingX = false
      -- Forward
      if keyboard.W.keydown then
      isMovingZ = true
      -- Sprinting
      if keyboard.LEFT_SHIFT.keydown then
        p.direction.z = 10.0
      elseif (not keyboard.LEFT_SHIFT.keydown) then
          p.direction.z = 5.0
      end
      -- Backward
      elseif keyboard.S.keydown then
      isMovingZ = true
      -- Sprinting
      if keyboard.LEFT_SHIFT.keydown then
        p.direction.z = -10.0
      elseif (not keyboard.LEFT_SHIFT.keydown) then
        p.direction.z = -5.0
      end
      -- Stop Moving
      elseif (not keyboard.W.keydown and keyboard.W.updated) or
           (not keyboard.S.keydown and keyboard.S.updated) then
      isMovingZ = false
      p.direction.z = 0
      end

      -- Left
      if keyboard.A.keydown then
      isMovingX = true
      p.direction.x = 5.0
      -- Sprinting
      if keyboard.LEFT_SHIFT.keydown then
        p.direction.x = 10.0
      elseif (not keyboard.LEFT_SHIFT.keydown) then
        p.direction.x = 5.0
      end
      -- Right
      elseif keyboard.D.keydown then
      isMovingX = true
      p.direction.x = -5.0
      -- Sprinting
      if keyboard.LEFT_SHIFT.keydown then
        p.direction.x = -10.0
      elseif (not keyboard.LEFT_SHIFT.keydown) then
        p.direction.x = -5.0
      end
      -- Stop Moving
      elseif (not keyboard.A.keydown and keyboard.A.updated) or
           (not keyboard.D.keydown and keyboard.D.updated) then
      p.direction.x = 0
      isMovingX = false
      end
      -- Update direction vector with movement/store the direction
      local up = ffi.new("kmVec3", 0, 1, 0)
      local qForward = ffi.new("kmQuaternion[1]")
      local pForward = ffi.new("kmVec3", -p.direction.x, p.direction.y, -p.direction.z)
      kazmath.kmQuaternionLookRotation(qForward, pForward, up)
      -- Rotate player to face direction moving
      if isMovingX == true or isMovingZ == true then
      pTransform.rotation = qForward[0]
      end
      ]]
    else
      p.direction.x = 0
      p.direction.z = 0
      p.sprintToggle = false
      local qForward = ffi.new("kmQuaternion[1]")
      local pForward = ffi.new("kmVec3", -p.direction.x, p.direction.y, -p.direction.z)
      kazmath.kmQuaternionLookRotation(qForward, pForward, up)
      pTransform.rotation = qForward[0]
      pTransform.position.x = pTransform.position.x
      pTransform.position.y = -3.0
      pTransform.position.z = pTransform.position.z
    end
  end
end

io.write("Loaded the Player Movement system\n")
return system
