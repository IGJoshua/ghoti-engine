local system = {}
system.shutdown = nil

local kazmath = engine.kazmath
local keyboard = engine.keyboard
local input = engine.input
local gamepad = engine.gamepad
local mouse = engine.mouse

local timer = 0
system.components = {}
system.components[1] = "camera_list"

function system.init(scene)
  input:register("swapcamera", input.BUTTON(keyboard["1"], gamepad.buttons.back))
end

function system.run(scene, uuid, dt)
  local manager = scene:getComponent("camera_list", uuid)
  
  timer = timer + dt
  manager.totalTime = manager.totalTime + dt
  manager.timerTick = manager.timerTick + dt
  -- Swap the active camera
  if input.swapcamera.keydown and input.swapcamera.updated then
    -- Change the index of the current active camera
    manager.currActiveCamera = manager.currActiveCamera + 1.0
    -- Reset index to 0, if index is the last the camera
    if manager.currActiveCamera > 2 then
      manager.currActiveCamera = 1.0
    end
    if manager.currActiveCamera == 1.0 then
      scene:getComponent("camera_player", scene.ptr.mainCamera).isOn = 0.0
      scene.ptr.mainCamera = manager.mainCamera
      scene:getComponent("camera_main", scene.ptr.mainCamera).isOn = 1.0
      io.write("Main Camera ON, Player Camera OFF\n")
    elseif manager.currActiveCamera == 2.0 then
      scene:getComponent("camera_main", scene.ptr.mainCamera).isOn = 0.0
      scene.ptr.mainCamera = manager.playerCamera
      scene:getComponent("camera_player", scene.ptr.mainCamera).isOn = 1.0
      io.write("Main Camera OFF, Player Camera ON\n")
    end
  end
end

io.write("Loaded the Camera Manager system\n")

return system
